# SigurScan — OP-IMP Impersonation Scam Atlas România 2024–2026

Version: `2026-06-12`

## Scope
Atlas product-grade pentru impersonare: instituții, bănci/fintech, curieri, suport tehnic, familie/prieteni, BEC/facturi, persoane publice/investiții, marketplace, retail giveaways, ONG/donații, romance și autorități internaționale/sextortion.

Atlasul NU decide verdictul final. Produce `semantic_review`, `reason_codes`, `signals`, `verification_sources`, false-positive guards și fixtures. Verdictul final rămâne în EvidenceGate.

## Counts

- Families: 12
- Evidence signals: 48
- Verification source entries: 18
- Regression fixtures: 120 (`PERICULOS`: 60, `SUSPECT`: 30, `SIGUR`: 30)
- Source index: 23

## Families

### IMP-01 — Instituții de stat: ANAF, Poliție, DNSC, instanțe, Interpol/Europol

Impersonarea unei autorități române sau internaționale pentru a cere bani, date, documente, card sau pentru a crea panică legală/fiscală.

- Channels: sms, email, html_email, pdf, phone_transcript, whatsapp, ocr_image

- Identity: instituție publică / autoritate / poliție / ANAF / DNSC / instanță

- Attack goals: bani, card, OTP, login, date_personale, IBAN schimbat

- High risk: provider malicious, domeniu neoficial + ANAF/Poliție + card/OTP, IBAN comercial pentru stat, QR/wallet pentru amendă/taxă, document fals cu legitimație/ordonanță

- False-positive guards: emailuri ANAF/SPV reale, notificări oficiale în SPV, comunicate fără link de plată, domenii gov/anaf oficiale fără cerere sensibilă


### IMP-02 — Bancă/fintech: BNR, bancă, Revolut, cont sigur, OTP, transfer preventiv

Impersonarea băncii, BNR, fintech sau unui departament antifraudă pentru a obține coduri, transferuri sau acces la cont.

- Channels: sms, email, phone_transcript, whatsapp, html_email, ocr_image

- Identity: bancă / BNR / Revolut / antifraudă / poliție financiară

- Attack goals: OTP, login, card, bani, remote_access, crypto

- High risk: BNR/cont sigur + transfer, OTP cerut de persoană, remote access + banking, card/PIN/CVV cerut prin SMS/email/telefon, crypto ATM/QR

- False-positive guards: OTP legitim de la bancă cu mesaj clar 'nu comunica', campanii educaționale bancare, login pe domeniu oficial/app oficial, notificări push in-app


### IMP-03 — Curierat: FAN, Poșta, Sameday, DHL, taxă colet, locker, cod WhatsApp

Impersonarea curierilor pentru taxe mici, adresă/locker, card, cod WhatsApp sau date personale.

- Channels: sms, email, html_email, whatsapp, qr, ocr_image

- Identity: curier / Poșta Română / FAN Courier / Sameday / DHL

- Attack goals: card, CVV, OTP, whatsapp_code, date_personale, bani

- High risk: domeniu neoficial + curier + card/CVV, cod WhatsApp cerut, FAN/Posta/DHL lookalike + taxe, provider malicious

- False-positive guards: tracking oficial curier, AWB real pe domeniu oficial fără card/OTP, email logistic de la brand/furnizor cunoscut


### IMP-04 — Suport tehnic: Microsoft/Apple/ISP, pop-up infectare, AnyDesk/TeamViewer, gift cards

Fake tech support sau pop-up malware care pretinde Microsoft/Apple/ISP și cere apel, remote access, plată crypto/gift card sau instalare app.

- Channels: link, html_email, phone_transcript, ocr_image, qr, pdf

- Identity: Microsoft / Apple / ISP / antivirus / suport tehnic

- Attack goals: remote_access, gift_card, crypto, card, login, date_personale

- High risk: pop-up cu număr telefon Microsoft, remote access cerut de suport nesolicitat, gift card/crypto pentru suport, download neoficial

- False-positive guards: notificări reale OS fără telefon, support inițiat de user pe domeniu oficial, download oficial app store/Microsoft Store


### IMP-05 — Rudă/prieten: telefon stricat, copil, nepot, cont WhatsApp compromis

Impersonare membru al familiei sau contact compromis pentru bani urgenti, coduri WhatsApp sau schimbare număr.

- Channels: whatsapp, sms, social_dm, phone_transcript

- Identity: rudă / copil / nepot / prieten / contact WhatsApp compromis

- Attack goals: bani, OTP, whatsapp_code, date_personale

- High risk: cod WhatsApp cerut, cont nou + bani urgent, nu permite apel voce, petiție + cod verificare, provider malicious link

- False-positive guards: mesaje normale de familie fără bani/coduri, cerere verificată prin apel pe număr vechi, parolă de familie confirmată


### IMP-06 — BEC/factură: CEO fraud, CFO, schimbare IBAN, furnizor fals

Business Email Compromise: impersonare CEO/furnizor/contabil pentru schimbare IBAN, factură urgentă sau plată către cont nou.

- Channels: email, html_email, pdf, whatsapp, attachment

- Identity: CEO / CFO / furnizor / contabil / partener business

- Attack goals: bani, IBAN schimbat, invoice_payment, date_contabile

- High risk: schimbare IBAN + domeniu sender mismatch, reply-to diferit, factură identică cu IBAN schimbat, urgență/confidențialitate, provider malicious attachment/link

- False-positive guards: domeniu furnizor cunoscut + confirmare telefonică pe număr existent, PO/factură în sistem ERP, IBAN validat anterior


### IMP-07 — Persoane publice/deepfake investiții

Impersonare persoane publice, directori de companii sau branduri pentru investiții false, crypto/trading sau acțiuni/tokenuri.

- Channels: social_dm, email, link, ocr_image, phone_transcript

- Identity: persoană publică / CEO / brand energetic / presă clonată

- Attack goals: crypto, card, remote_access, login, bani

- High risk: profit garantat + brand public + domeniu neoficial, ASF alert, remote access, crypto wallet/QR, deepfake + card/crypto

- False-positive guards: campanie reală pe domeniu oficial, entitate autorizată ASF/BNR, fără cerere de bani/date în link primit


### IMP-08 — Marketplace: OLX/Publi24/cumpărător fals, escrow/livrare falsă

Impersonare cumpărător, platformă marketplace sau curier pentru card/CVV/OTP sau escrow fals.

- Channels: whatsapp, sms, social_dm, email, html_email, link

- Identity: OLX / Publi24 / Facebook Marketplace / curier escrow

- Attack goals: card, CVV, OTP, bani, date_personale

- High risk: card/CVV ca să primești bani, link non-OLX, curier escrow fals, OTP cerut pentru primire bani, full advance către persoană

- False-positive guards: tranzacție în platformă oficială, fără link de card primit de la cumpărător, predare/ramburs controlat


### IMP-09 — Retail/brand giveaway: eMAG/Altex/vouchere/premii false

Impersonarea retailerilor/brandurilor pentru vouchere, premii, carduri cadou, sondaje sau giveaway-uri false.

- Channels: sms, email, html_email, social_dm, qr, ocr_image

- Identity: eMAG / Altex / retailer / supermarket / brand promo

- Attack goals: card, date_personale, shipping_fee, subscription, OTP

- High risk: premiu + taxă/card, domeniu lookalike, abonament ascuns, provider malicious

- False-positive guards: newsletter real de pe domeniu oficial/ESP valid + final URL oficial, promoție afișată pe canal oficial, nu cere card/CVV/OTP pentru premiu


### IMP-10 — ONG/donații false

Impersonare ONG/adăpost/caz umanitar pentru donații urgente, cont personal sau crypto.

- Channels: social_dm, email, html_email, sms, qr, ocr_image

- Identity: ONG / adăpost animale / cauză umanitară / persoană bolnavă

- Attack goals: bani, card, crypto, date_personale

- High risk: ONG pretins + IBAN persoană fizică, donație crypto/gift card, presiune emoțională + lipsă CUI/asociație, imagini reutilizate

- False-positive guards: ONG verificabil în registre publice + cont organizație + site oficial, campanie pe domeniu oficial cunoscut


### IMP-11 — Romance/militar/doctor străin

Impersonare partener romantic, militar, doctor sau străin în nevoie pentru bani, taxe vamale, bilete, crypto/gift card.

- Channels: social_dm, whatsapp, email, phone_transcript

- Identity: partener romantic / militar / doctor / străin / marinar

- Attack goals: bani, gift_card, crypto, date_personale

- High risk: romance + bani urgent, refuz video call, gift card/crypto, documente pașaport/vamă neverificabile

- False-positive guards: relație existentă offline, cereri fără bani/date, verificare independentă prin persoane cunoscute


### IMP-12 — Autorități internaționale/sextortion/legal threat

Impersonare Europol/Interpol/FBI/instanțe/avocați sau amenințări sextortion pentru bani/crypto/gift card.

- Channels: email, pdf, html_email, phone_transcript, ocr_image

- Identity: Europol / Interpol / poliție internațională / avocat / instanță / hacker

- Attack goals: crypto, gift_card, bani, date_personale

- High risk: autoritate internațională + crypto/gift card, document PDF cu acuzații sexuale, amenințare publicare poze + wallet, provider malicious

- False-positive guards: notificări legale reale prin canale oficiale, nu gift card/crypto, documente verificabile în portal oficial


## Gate invariants

- Atlas never sets final verdict directly.

- Atlas sets semantic_review, signal list, reason_codes and max_solo_effect.

- Text-only marketing max SUSPECT.

- Hidden link only max SUSPECT.

- Tracking link only max SUSPECT.

- Registry NO_MATCH solo max SUSPECT.

- SOURCE_ERROR/NOT_CONFIGURED never lowers risk to SIGUR.

- Provider malicious/WebRisk/URLhaus hit hard dangerous.

- Official clean + no sensitive request can be SIGUR.

- Established clean + no sensitive request can be SIGUR.

- Identity spoof + hard sensitive/wrong channel is PERICULOS.


## Top acceptance tests

- FAN fake locker + card/CVV -> PERICULOS

- BT/BCR/BNR cont sigur + transfer -> PERICULOS

- WhatsApp family new number + money -> PERICULOS

- OLX receive money + card/CVV -> PERICULOS

- Microsoft pop-up phone + gift card/remote access -> PERICULOS

- BEC supplier IBAN change + reply-to mismatch + urgency -> PERICULOS

- eMAG newsletter with final official URL + no sensitive request -> SIGUR

- FAN official AWB tracking + no card/OTP -> SIGUR

- OTP legitimate warning that says do not share code -> SIGUR

- Corpus-only lottery/voucher/marketing text + provider clean/no sensitive -> max SUSPECT or SIGUR depending official context


## Critical gaps

- Identity object with claimed_identity, verified_identity, brand_family, official_mismatch status

- Wrong-channel sensitive request detector: OTP/card/CVV/password/remote_access/crypto/gift_card

- Email header alignment for BEC and brand impersonation: From, Reply-To, Return-Path, SPF/DKIM/DMARC

- Phone transcript scenario parser: cont sigur, credit pe numele tău, BNR/Poliție handoff

- Business invoice/BEC IBAN-change detector and supplier master-data comparison

- Official verification sources with confidence/caveat and not_confirmed support

- False-positive guard runner for marketing/tracking/OTP/official tracking


## Do not hard-verdict

- marketing urgency

- hidden link only

- tracking link only

- shortener only

- corpus similarity only

- registry not found without sensitive request

- source error/not configured

- brand mention without link/payment/sensitive request

- AI/deepfake suspicion without payment/credential/remote access context


## Source index

- `src-sigurantaonline-uniti` — Siguranța Online — https://sigurantaonline.ro/uniti-impotriva-escrocheriilor/ — confidence `high`

- `src-ancom-spoofing` — ANCOM — https://www.ancom.ro/en/about-us/media-en/press-releases/spoofing-via-phone-number58-what-ancom-does-and-what-users-can-do/ — confidence `high`

- `src-fan-smishing-2026` — FAN Courier — https://www.fancourier.ro/alerta-de-smishing/ — confidence `high`

- `src-posta-phishing-sms` — Poșta Română — https://www.posta-romana.ro/a1941/stiri/o-noua-tentativa-de-phishing-prin-sms-in-numele-postei-romane.html — confidence `high`

- `src-dhl-fraud-awareness` — DHL România — https://www.dhl.com/ro-en/home/footer/fraud-awareness.html — confidence `high`

- `src-olx-false-links` — OLX România — https://blog.olx.ro/2020/12/ai-grija-la-linkurile-false-pentru-articole-platite-vezi-cum-te-protejezi-de-cele-mai-noi-atacuri-de-phishing/ — confidence `high`

- `src-bt-siguranta` — Banca Transilvania — https://www.bancatransilvania.ro/siguranta-online — confidence `high`

- `src-bcr-phishing` — BCR — https://www.bcr.ro/ro/persoane-fizice/informatii-utile/tentative-de-frauda-phishing — confidence `high`

- `src-raiffeisen-sec-online` — Raiffeisen Bank România — https://www.raiffeisen.ro/ro/persoane-fizice/in-sprijinul-tau/securitate-online.html — confidence `medium`

- `src-revolut-fraud` — Revolut România — https://www.revolut.com/en-RO/about-fraud-and-scam/ — confidence `high`

- `src-microsoft-techsupport` — Microsoft Support — https://support.microsoft.com/en-us/windows/protect-yourself-from-tech-support-scams-2ebf91bd-f94c-2a8a-e541-f5c800d18435 — confidence `high`

- `src-apple-phishing` — Apple Support — https://support.apple.com/en-us/102568 — confidence `high`

- `src-whatsapp-compromised` — WhatsApp Help Center — https://faq.whatsapp.com/1131652977717250 — confidence `medium`

- `src-asf-alerts` — Autoritatea de Supraveghere Financiară — https://asfromania.ro/ro/a/19/alerte-investitori---informari — confidence `high`

- `src-bnr-registre` — Banca Națională a României — https://www.bnr.ro/2349-registre-si-liste — confidence `high`

- `src-hidroelectrica-warning` — Hidroelectrica — https://www.hidroelectrica.ro/press-release/1d738954-4c1b-1ad9-c046-4d0d6001e187 — confidence `high`

- `src-anpc` — ANPC — https://anpc.ro/ — confidence `medium`

- `src-ghiseul` — Ghișeul.ro — https://www.ghiseul.ro/ — confidence `high`

- `src-meta-scams` — Meta/Facebook Help Center — https://www.facebook.com/help/235353253505947 — confidence `medium`

- `src-ftc-romance` — Federal Trade Commission — https://consumer.ftc.gov/articles/what-know-about-romance-scams — confidence `medium`

- `src-ftc-charity` — Federal Trade Commission — https://consumer.ftc.gov/articles/charity-scams — confidence `medium`

- `src-ic3-bec` — FBI IC3 — https://www.ic3.gov/AnnualReport/Reports/2024_IC3Report.pdf — confidence `medium`

- `src-anaf` — ANAF — https://www.anaf.ro/ — confidence `high`
